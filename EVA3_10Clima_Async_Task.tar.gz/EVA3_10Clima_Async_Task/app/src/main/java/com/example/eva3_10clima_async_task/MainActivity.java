package com.example.eva3_10clima_async_task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    Clima[] Ciudades;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new Clima().execute();
        lv = findViewById(R.id.lv);
        //lv.setAdapter(new ClimaAdapter(this, R.layout.layout_clima, Ciudades));
        //lv.setOnItemClickListener(this);
    }



}
class Clima extends AsyncTask<Void, Void, String> {

    final String ruta = "https://samples.openweathermap.org/data/2.5/group?id=524901,703448,2643743&units=metric&appid=b6907d289e10d714a6e88b30761fae22";
    @Override
    protected String doInBackground(Void... voids) {
        String resultado  = null;
        //aqui hacemos la conexion
        try {
            URL url = new URL(ruta);
            HttpsURLConnection http = (HttpsURLConnection)url.openConnection();
            http.connect();
            if(http.getResponseCode() == HttpsURLConnection.HTTP_OK){
                //leer respuesta
                String linea;
                StringBuffer lineas = new StringBuffer();
                InputStream inputStream = http.getInputStream();
                InputStreamReader inputSreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputSreamReader);

                while((linea = bufferedReader.readLine()) != null){
                    lineas.append(linea);
                }
                resultado = lineas.toString();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resultado;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if(s != null){
            Climaa[] Ciudades;
            //aqui procesamos los objetos
            //Log.wtf("cadena", s);
           // Toast.makeText(getAplicationContext(),s,Toast.LENGTH_LONG).show();
            try {
                JSONObject jsonClima = new JSONObject(s);
                JSONArray jsonCiudades = jsonClima.getJSONArray("list");
                for (int i = 0; i <jsonCiudades.length(); i++){
                    JSONObject jsonCiudad = jsonCiudades.getJSONObject(i);
                    //nombre
                    jsonCiudad.getString("name");
                    Log.wtf("nombre", jsonCiudad.getString("name"));
                }
                Ciudades = new Climaa[]{
                        new Climaa(),
                };
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
